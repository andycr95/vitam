<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\vehicle;
use Faker\Generator as Faker;

$factory->define(vehicle::class, function (Faker $faker) {
    return [
        //
    ];
});
