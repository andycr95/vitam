<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\branchoffice;
use Faker\Generator as Faker;

$factory->define(branchoffice::class, function (Faker $faker) {
    return [
        //
    ];
});
