<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\city;
use Faker\Generator as Faker;

$factory->define(city::class, function (Faker $faker) {
    return [
        //
    ];
});
