<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\recomended;
use Faker\Generator as Faker;

$factory->define(recomended::class, function (Faker $faker) {
    return [
        //
    ];
});
