<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\typeSale;
use Faker\Generator as Faker;

$factory->define(typeSale::class, function (Faker $faker) {
    return [
        //
    ];
});
