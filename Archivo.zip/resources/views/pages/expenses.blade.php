@extends('layouts.app')

@section('content')
    <h1>Expenses</h1>
@endsection