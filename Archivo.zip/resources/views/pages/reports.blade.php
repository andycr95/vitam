@extends('layouts.app')

@section('content')
    <h1>Reports</h1>
@endsection