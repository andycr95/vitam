<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php $__currentLoopData = $branchoffice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branchoffice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e(Breadcrumbs::render('branchoffice', $branchoffice)); ?>

    <h3 class="text-dark mb-4">Sucursal - <?php echo e($branchoffice->name); ?></h3>
    <div class="row mb-3">
        <div class="col-lg-4">
            <?php if($branchoffice->vehicles->count() > 0): ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="text-primary font-weight-bold m-0">Vehiculos</h6>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $branchoffice->vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4 class="small font-weight-bold"><?php echo e($vehicle->placa); ?>

                        <?php if($vehicle->status == 0): ?>
                            <span class="badge badge-success float-right">Vendida</span>
                        <?php else: ?>
                            <span class="badge badge-primary float-right">Por vender</span>
                        <?php endif; ?>
                    </h4>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
            <?php if($branchoffice->sales->count() > 0): ?>
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="text-primary font-weight-bold m-0">Vehiculos vendidos</h6>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $branchoffice->sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h4 class="small font-weight-bold"><?php echo e($sale->vehicle->placa); ?><span class="float-right"><?php echo e($sale->vehicle->payments->count()); ?> pagos</span></h4>
                            <div class="progress progress-sm mb-3">
                                <?php if(($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100 <= 20): ?>
                                    <div class="progress-bar bg-danger" aria-valuenow="<?php echo e(($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e((($sale->vehicle->payments->count())/$sale->vehicle->type->counter)*100); ?>%;">
                                        <span class="sr-only"><?php echo e((($sale->vehicle->payments->count())/$sale->vehicle->type->counter)*100); ?></span>
                                    </div>
                                <?php elseif(($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100 > 20 && ($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100 < 50): ?>
                                    <div class="progress-bar bg-warning" aria-valuenow="<?php echo e(($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e((($sale->vehicle->payments->count())/$sale->vehicle->type->counter)*100); ?>%;">
                                        <span class="sr-only"><?php echo e((($sale->vehicle->payments->count())/$sale->vehicle->type->counter)*100); ?></span>
                                    </div>
                                <?php elseif(($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100 > 50 && ($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100 < 70): ?>
                                    <div class="progress-bar bg-primary" aria-valuenow="<?php echo e(($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e((($sale->vehicle->payments->count())/$sale->vehicle->type->counter)*100); ?>%;">
                                        <span class="sr-only"><?php echo e((($sale->vehicle->payments->count())/$sale->vehicle->type->counter)*100); ?></span>
                                    </div>
                                <?php elseif(($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100 > 70 && ($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100 < 100): ?>
                                    <div class="progress-bar bg-info" aria-valuenow="<?php echo e(($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e((($sale->vehicle->payments->count())/$sale->vehicle->type->counter)*100); ?>%;">
                                        <span class="sr-only"><?php echo e((($sale->vehicle->payments->count())/$sale->vehicle->type->counter)*100); ?></span>
                                    </div>
                                <?php elseif(($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100 == 100): ?>
                                    <div class="progress-bar bg-success" aria-valuenow="<?php echo e(($sale->vehicle->payments->count()/$sale->vehicle->type->counter)*100); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e((($sale->vehicle->payments->count())/$sale->vehicle->type->counter)*100); ?>%;">
                                        <span class="sr-only"><?php echo e((($sale->vehicle->payments->count())/$sale->vehicle->type->counter)*100); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
            <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="text-primary font-weight-bold m-0">Empleados</h6>
                    </div>
                    <div class="card-body">
                        <table class="table dataTable my-0" id="dataTable">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Telefono</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $branchoffice->employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($employee->user->name); ?> <?php echo e($employee->user->last_name); ?></td>
                                    <td><?php echo e($employee->user->phone); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
        </div>
        <div class="col-lg-8">
            <div class="row">
                <div class="col">
                    <div class="card shadow mb-3">
                        <div class="card-header py-3">
                            <p class="text-primary m-0 font-weight-bold">Información de sucursal</p>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('updateBranchoffice', $branchoffice->id)); ?>"  enctype="multipart/form-data"  method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="first_name"><strong>Nombre</strong></label>
                                            <input disabled class="form-control" type="text" value="<?php echo e($branchoffice->name); ?>" name="first_name">
                                            <input type="hidden" value="<?php echo e($branchoffice->id); ?>" name="id">
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="encargado"><strong>Encargado</strong></label>
                                            <select name="encargado" class="form-control" disabled>
                                            <option style="color: red;" value="<?php echo e($branchoffice->employee_id); ?>"><?php echo e($branchoffice->employee->user->name); ?></option>
                                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->user->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="address"><strong>Dirección</strong></label>
                                            <input class="form-control" type="text" disabled value="<?php echo e($branchoffice->address); ?>" name="address">
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="city"><strong>Ciudad</strong></label>
                                            <select name="city" class="form-control" disabled>
                                            <option style="color: red;" value="<?php echo e($branchoffice->city_id); ?>"><?php echo e($branchoffice->city->name); ?></option>
                                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div id="modal-buttons" class="form-group">
                                    <button disabled id="branchSave" class="btn btn-primary btn-sm" type="submit">Guardar</button>
                                    <button class="btn btn-info btn-sm" id="branchUpdate" type="button"><span>Actualizar</span></button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="/js/branchoffice.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/andycaicedo/Documents/projects/vitam/resources/views/pages/branchoffice/profile.blade.php ENDPATH**/ ?>