<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Dashboard - Vitam</title> 
    <link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700">
    <link rel="stylesheet" href="/css/styles.min.css">
    <link rel="stylesheet" href="/css/app.css">
</head>
 
<body id="page-top">
    <div id="wrapper">
        <?php echo $__env->make('layouts.navbar-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex flex-column" id="content-wrapper">
            <div id="content">
                <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="/js/script.min.js"></script>
    <script src="/js/app.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php if(session()->has('success')): ?>
        <script>toastr.success("<?php echo e(session('success')); ?>")</script>
    <?php elseif(session()->has('info')): ?>
        <script>toastr.info("<?php echo e(session('info')); ?>")</script>
    <?php elseif(session()->has('warning')): ?>
        <script>toastr.warning("<?php echo e(session('warning')); ?>")</script>
    <?php elseif(session()->has('danger')): ?>
        <script>toastr.error("<?php echo e(session('danger')); ?>")</script>
    <?php endif; ?>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }});
    </script>
</body>

</html><?php /**PATH /Users/andycaicedo/Documents/projects/vitam/resources/views/layouts/app.blade.php ENDPATH**/ ?>