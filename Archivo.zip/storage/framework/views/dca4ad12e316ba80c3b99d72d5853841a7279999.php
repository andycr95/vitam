<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php $__currentLoopData = $vehicle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e(Breadcrumbs::render('vehicle', $vehicle)); ?>

    <div class="row mb-3">
        <div class="col-lg-5">
            <?php if(count($vehicle->payments) > 0): ?>
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="text-primary font-weight-bold m-0"><?php echo e($vehicle->placa); ?><span class="float-right"><?php echo e($vehicle->payments->count()); ?> pagos</span></h6>
                    </div>
                    <div class="card-body">
                        <div class="progress progress-sm mb-3">
                            <?php if(($vehicle->payments->count()/$vehicle->type->counter)*100 <= 20): ?>
                                <div class="progress-bar bg-danger" aria-valuenow="<?php echo e(($vehicle->payments->count()/$vehicle->type->counter)*100); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e((($vehicle->payments->count())/$vehicle->type->counter)*100); ?>%;">
                                    <span class="sr-only"><?php echo e((($vehicle->payments->count())/$vehicle->type->counter)*100); ?></span>
                                </div>
                            <?php elseif(($vehicle->payments->count()/$vehicle->type->counter)*100 > 20 && ($vehicle->payments->count()/$vehicle->type->counter)*100 < 50): ?>
                                <div class="progress-bar bg-warning" aria-valuenow="<?php echo e(($vehicle->payments->count()/$vehicle->type->counter)*100); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e((($vehicle->payments->count())/$vehicle->type->counter)*100); ?>%;">
                                    <span class="sr-only"><?php echo e((($vehicle->payments->count())/$vehicle->type->counter)*100); ?></span>
                                </div>
                            <?php elseif(($vehicle->payments->count()/$vehicle->type->counter)*100 > 50 && ($vehicle->payments->count()/$vehicle->type->counter)*100 < 70): ?>
                                <div class="progress-bar bg-primary" aria-valuenow="<?php echo e(($vehicle->payments->count()/$vehicle->type->counter)*100); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e((($vehicle->payments->count())/$vehicle->type->counter)*100); ?>%;">
                                    <span class="sr-only"><?php echo e((($vehicle->payments->count())/$vehicle->type->counter)*100); ?></span>
                                </div>
                            <?php elseif(($vehicle->payments->count()/$vehicle->type->counter)*100 > 70 && ($vehicle->payments->count()/$vehicle->type->counter)*100 < 100): ?>
                                <div class="progress-bar bg-info" aria-valuenow="<?php echo e(($vehicle->payments->count()/$vehicle->type->counter)*100); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e((($vehicle->payments->count())/$vehicle->type->counter)*100); ?>%;">
                                    <span class="sr-only"><?php echo e((($vehicle->payments->count())/$vehicle->type->counter)*100); ?></span>
                                </div>
                            <?php elseif(($vehicle->payments->count()/$vehicle->type->counter)*100 == 100): ?>
                                <div class="progress-bar bg-success" aria-valuenow="<?php echo e(($vehicle->payments->count()/$vehicle->type->counter)*100); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e((($vehicle->payments->count())/$vehicle->type->counter)*100); ?>%;">
                                    <span class="sr-only"><?php echo e((($vehicle->payments->count())/$vehicle->type->counter)*100); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div style="max-height: 300px; overflow-y: auto;">
                            <table class="table dataTable my-0" id="dataTable">
                                <thead>
                                    <tr>
                                        <th>Nombre</th>
                                        <th>Monto</th>
                                        <th>Fecha</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $vehicle->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><h4 style="font-size: 14px;"><?php echo e($pay->sale->client->name); ?><span class="badge badge-success">Activo</span></h4></td>
                                        <td><span class="h3" style="font-size: 14px;">$<?php echo e($pay->amount); ?></span><br /><strong></strong></td>
                                        <td><p class="text-muted" style="font-size: 12px;">&nbsp;<?php echo e(($pay->created_at)->diffForhumans()); ?></p></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="card shadow mb-4">
                    <div class="card-body">
                        <?php if($photo != false): ?>
                            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($photo->photo1 == null): ?>

                                <?php else: ?>
                                    <img class="mb-3 mt-4" src="/storage/<?php echo e($photo->photo1); ?>"  id="photo1" alt="<?php echo e($vehicle->placa); ?>" width="160" height="160">
                                <?php endif; ?>
                                <?php if($photo->photo2 == null): ?>
                                    <form action="<?php echo e(route('updatePhotovehicle')); ?>" id="form1" enctype="multipart/form-data"  method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                            <input type="file" class="btn btn-primary btn-block" name="photo2" id="photo1" value="Agregar foto 2" />
                                            <input type="hidden" name="id" value="<?php echo e($vehicle->id); ?>"/>
                                    </form><br>
                                <?php else: ?>
                                    <img class="mb-3 mt-4" alt="<?php echo e($vehicle->placa); ?>" id="photo2" src="/storage/<?php echo e($photo->photo2); ?>" width="160" height="160">
                                <?php endif; ?>
                                <?php if($photo->photo3 == null): ?>
                                    <form action="<?php echo e(route('updatePhotovehicle')); ?>" id="form2" enctype="multipart/form-data"  method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                            <input type="file" class="btn btn-primary btn-block"  name="photo3" id="photo2" value="Agregar foto 3" />
                                            <input type="hidden" name="id" value="<?php echo e($vehicle->id); ?>"/>
                                    </form>
                                <?php else: ?>
                                    <img class="mb-3 mt-4" alt="<?php echo e($vehicle->placa); ?>"  id="photo3" src="/storage/<?php echo e($photo->photo3); ?>" width="160" height="160">
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <h4>No tiene fotos</h4>
                            <form action="<?php echo e(route('updatePhotovehicle')); ?>" id="form"  enctype="multipart/form-data"  method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                    <input type="file" class="btn btn-primary btn-block" value="Agregar" name="photo1" id="photo" value="Agregar foto 1"/>
                                    <input type="hidden" name="id" value="<?php echo e($vehicle->id); ?>"/>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
        </div>
        <div class="col-lg-7">
            <div class="row">
                <div class="col">
                    <div class="card shadow mb-3">
                        <div class="card-header py-3">
                            <p class="text-primary m-0 font-weight-bold">Información del vehiculo</p>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('updateVehicle', $vehicle->id)); ?>"  enctype="multipart/form-data"  method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="placa"><strong>Placa</strong></label>
                                            <input disabled class="form-control" type="text" value="<?php echo e($vehicle->placa); ?>" name="placa" required>
                                            <input type="hidden" value="<?php echo e($vehicle->id); ?>" name="id">
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="model"><strong>Modelo</strong></label>
                                            <input disabled class="form-control" id="model" type="text" value="<?php echo e($vehicle->model); ?>" name="model" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="color"><strong>Color</strong></label>
                                            <input disabled class="form-control" id="color" type="text" value="<?php echo e($vehicle->color); ?>" name="color" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col">
                                            <label for="color"><strong>Precio</strong></label>
                                            <input disabled class="form-control" id="fee" type="text" value="<?php echo e($vehicle->fee); ?>" name="fee" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="motor"><strong>Motor</strong></label>
                                        <input class="form-control" type="text" value="<?php echo e($vehicle->motor); ?>" id="motor" disabled name="motor" required>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="chasis"><strong>Chasis</strong></label>
                                        <input class="form-control" type="text" value="<?php echo e($vehicle->chasis); ?>" id="chasis" disabled name="chasis" required>
                                        </div>
                                    </div>
                                </div>
                                <div id="modal-buttons" class="form-group">
                                    <button disabled id="vehicleSave" class="btn btn-primary btn-sm" type="submit">Guardar</button>
                                    <button class="btn btn-info btn-sm" id="vehicleUpdate" type="button"><span>Actualizar</span></button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div id="myModal" class="modalphoto">
        <!-- The Close Button -->
        <span id="close" class="close">&times;</span>
        <!-- Modal Content (The Image) -->
        <img class="modal-content" id="img01">
        <!-- Modal Caption (Image Text) -->
        <div id="caption"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="/js/vehicle.js"></script>
    <script src="/js/photos.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/andycaicedo/Documents/projects/vitam/resources/views/pages/vehicles/profile.blade.php ENDPATH**/ ?>