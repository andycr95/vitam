<footer class="bg-white sticky-footer">
    <div class="container my-auto">
        <div class="text-center my-auto copyright"><span>Copyright © Brand 2019</span></div>
    </div>
</footer><?php /**PATH /Users/andycaicedo/Documents/projects/vitam/resources/views/layouts/footer.blade.php ENDPATH**/ ?>