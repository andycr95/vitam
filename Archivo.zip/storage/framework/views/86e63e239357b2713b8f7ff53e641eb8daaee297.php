<nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0">
        <div class="container-fluid d-flex flex-column p-0">
            <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                <div class="sidebar-brand-icon rotate-n-15"></div>
                <div class="sidebar-brand-text mx-3"><span>Vitam venture</span></div>
            </a>
            <ul class="nav navbar-nav text-light" id="accordionSidebar">
                <li class="nav-item" role="presentation">
                    <?php if(strpos(url()->current(), "home")): ?>
                        <a class="nav-link active" href="<?php echo e(route('home')); ?>">
                            <i class="fas fa-tachometer-alt"></i><span>Dashboard</span>
                        </a>
                    <?php else: ?>
                        <a class="nav-link" href="<?php echo e(route('home')); ?>">
                            <i class="fas fa-tachometer-alt"></i><span>Dashboard</span>
                        </a>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasAnyRole('Administrador')): ?>
                    <?php if(strpos(url()->current(), "branchoffices")): ?>
                        <a class="nav-link active" href="<?php echo e(route('branchOffices')); ?>">
                            <i class="fas fa-briefcase"></i><span>Sucursales</span>
                        </a>
                    <?php else: ?>
                        <a class="nav-link" href="<?php echo e(route('branchOffices')); ?>">
                            <i class="fas fa-briefcase"></i><span>Sucursales</span>
                        </a>
                    <?php endif; ?>
                    <?php if(strpos(url()->current(), "employees")): ?>
                        <a class="nav-link active" href="<?php echo e(route('employees')); ?>">
                            <i class="fas fa-people-carry"></i><span>Empleados</span>
                        </a>
                    <?php else: ?>
                        <a class="nav-link" href="<?php echo e(route('employees')); ?>">
                            <i class="fas fa-people-carry"></i><span>Empleados</span>
                        </a>
                    <?php endif; ?>
                    <?php if(strpos(url()->current(), "investors")): ?>
                        <a class="nav-link active" href="<?php echo e(route('investors')); ?>">
                            <i class="far fa-handshake"></i><span>Inversionistas</span>
                        </a>
                    <?php else: ?>
                        <a class="nav-link" href="<?php echo e(route('investors')); ?>">
                            <i class="far fa-handshake"></i><span>Inversionistas</span>
                        </a>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasAnyRole('Empleado|Administrador')): ?>
                    <?php if(strpos(url()->current(), "clients")): ?>
                        <a class="nav-link active" href="<?php echo e(route('clients')); ?>">
                            <i class="far fa-handshake"></i><span>Clientes</span>
                        </a>
                    <?php else: ?>
                        <a class="nav-link" href="<?php echo e(route('clients')); ?>">
                            <i class="fas fa-users"></i><span>Clientes</span>
                        </a>
                    <?php endif; ?>
                    <?php if(strpos(url()->current(), "sales")): ?>
                        <a class="nav-link active" href="<?php echo e(route('sales')); ?>">
                            <i class="fas fa-motorcycle"></i><span>Ventas</span>
                        </a>
                    <?php else: ?>
                        <a class="nav-link" href="<?php echo e(route('sales')); ?>">
                            <i class="fas fa-motorcycle"></i><span>Ventas</span>
                        </a>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if(strpos(url()->current(), "vehicles")): ?>
                        <a class="nav-link active" href="<?php echo e(route('vehicles')); ?>">
                            <i class="fas fa-motorcycle"></i><span>Vehículos</span>
                        </a>
                    <?php else: ?>
                        <a class="nav-link" href="<?php echo e(route('vehicles')); ?>">
                            <i class="fas fa-motorcycle"></i><span>Vehículos</span>
                        </a>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasAnyRole('Empleado|Administrador')): ?>
                    <?php if(strpos(url()->current(), "payments")): ?>
                        <a class="nav-link active" href="<?php echo e(route('payments')); ?>">
                            <i class="fas fa-money-check"></i><span>Recaudos</span>
                        </a>
                    <?php else: ?>
                        <a class="nav-link" href="<?php echo e(route('payments')); ?>">
                            <i class="fas fa-money-check"></i><span>Recaudos</span>
                        </a>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if(strpos(url()->current(), "reports")): ?>
                    <a class="nav-link active" href="<?php echo e(route('reports')); ?>">
                        <i class="far fa-chart-bar"></i><span>Reportes</span>
                    </a>
                    <?php else: ?>
                    <a class="nav-link" href="<?php echo e(route('reports')); ?>">
                        <i class="far fa-chart-bar"></i><span>Reportes</span>
                    </a>
                    <?php endif; ?>
                </li>
            </ul>
            <hr class="sidebar-divider my-0">
            <div class="text-center d-none d-md-inline"><button class="btn rounded-circle border-0"
                    id="sidebarToggle" type="button"></button></div>
        </div>
    </nav><?php /**PATH /Users/andycaicedo/Documents/projects/vitam/resources/views/layouts/navbar-side.blade.php ENDPATH**/ ?>